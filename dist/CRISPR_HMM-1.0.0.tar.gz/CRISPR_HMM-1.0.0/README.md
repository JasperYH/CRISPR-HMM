# CRISPR-HMM
Probabilistic alignment of CRISPR sequence data with hidden Markov model
